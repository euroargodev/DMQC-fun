%% NUM2ORDINAL Examples
% The function <www.mathworks.com/matlabcentral/fileexchange/42833
% |NUM2ORDINAL|> converts a numeric array to a character array containing
% the values together with suitable ordinal suffixes, e.g.: 12 -> '12th'.
% |NUM2ORDINAL| first rounds the input values to the nearest integer.
%
%% Basic Usage
% |NUM2ORDINAL| can be called with any numeric scalar:
num2ordinal(1)
num2ordinal(111)
%% Numeric Array
% |NUM2ORDINAL| accepts any array of |N| values and returns a character
% array of size |NxC|, where |C| is automatically determined by the values
% and the rows of the character array are linearly indexed from the input
% array. |NUM2ORDINAL| is fully vectorized and quite efficient.
num2ordinal([1,12,123,1234]) % vector
num2ordinal([1,123;12,1234]) % matrix
%% 2nd Input: Suffix Only
% The optional second input argument selects between returning both the
% values with suffixes (default) or just the suffixes by themselves:
num2ordinal(23,false) % default
num2ordinal(23,true)  % suffix only